import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            BufferedImage image = ImageIO.read(new File("src/resources/foto.png"));
            FloodFill floodFill = new FloodFill(image);

            floodFill.fill(10, 10, Color.RED); // Exemplo de ponto inicial e nova cor

            ImageIO.write(image, "png", new File("src/resources/resultado.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
