import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.Stack;

public class FloodFill {
    private BufferedImage image;

    public FloodFill(BufferedImage image) {
        this.image = image;
    }

    public void fill(int x, int y, Color newColor) {
        Color targetColor = new Color(image.getRGB(x, y));

        if (targetColor.equals(newColor)) return;

        Stack<int[]> stack = new Stack<>();
        stack.push(new int[]{x, y});

        while (!stack.isEmpty()) {
            int[] coords = stack.pop();
            int currX = coords[0];
            int currY = coords[1];

            if (currX < 0 || currX >= image.getWidth() || currY < 0 || currY >= image.getHeight()) continue;
            if (!new Color(image.getRGB(currX, currY)).equals(targetColor)) continue;

            image.setRGB(currX, currY, newColor.getRGB());

            stack.push(new int[]{currX + 1, currY});
            stack.push(new int[]{currX - 1, currY});
            stack.push(new int[]{currX, currY + 1});
            stack.push(new int[]{currX, currY - 1});
        }
    }
}
