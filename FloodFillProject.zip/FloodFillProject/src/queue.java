public class queue {
    private int[] queue;
    private int front;
    private int rear;
    private int size;

    public queue(int size) {
        this.size = size;
        queue = new int[size];
        front = -1;
        rear = -1;
    }

    public void enqueue(int value) {
        rear++;
        queue[rear] = value;
        if (front == -1) front = 0;
    }

    public int dequeue() {
        int value = queue[front];
        front++;
        if (front > rear) front = rear = -1; // Reinicia a fila
        return value;
    }

    public boolean isEmpty() {
        return front == -1;
    }
}
